import { Section, Text } from "@react-email/components";

import { theme } from "../theme/theme.js";

type Props = {
  code: string;
  label?: string;
};

export default function OTPBox({ code, label = "Tu código de verificación" }: Props) {
  const showLabel = label.trim().length > 0;
  const chars = code.split("");

  return (
    <Section
      style={{
        backgroundColor: theme.colors.surface,
        borderRadius: theme.radius.otp,
        padding: theme.spacing.lg,
        textAlign: "center",
        marginTop: theme.spacing.lg,
        border: `1px solid ${theme.colors.border}`,
      }}
    >
      {showLabel ? (
        <Text
          style={{
            color: theme.colors.muted,
            fontSize: "14px",
            margin: 0,
          }}
        >
          {label}
        </Text>
      ) : null}

      <table
        role="presentation"
        align="center"
        cellPadding="0"
        cellSpacing="0"
        style={{
          margin: showLabel ? `${theme.spacing.md} auto 0 auto` : "0 auto",
          maxWidth: "100%",
        }}
      >
        <tbody>
          <tr>
            {chars.map((ch, index) => {
              if (ch === " ") {
                return (
                  <td
                    key={`space-${index}`}
                    style={{
                      width: "10px",
                    }}
                  />
                );
              }

              return (
                <td
                  key={`ch-${index}`}
                  style={{
                    paddingRight: index === chars.length - 1 ? "0" : "8px",
                  }}
                >
                  <span
                    style={{
                      display: "inline-block",
                      width: "32px",
                      height: "44px",
                      lineHeight: "44px",
                      textAlign: "center",
                      backgroundColor: theme.colors.card,
                      border: `1px solid ${theme.colors.border}`,
                      borderRadius: "12px",
                      fontSize: "20px",
                      fontWeight: "700",
                      color: theme.colors.text,
                      fontFamily:
                        "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
                    }}
                  >
                    {ch}
                  </span>
                </td>
              );
            })}
          </tr>
        </tbody>
      </table>
    </Section>
  );
}
