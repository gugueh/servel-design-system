import { Body, Container, Head, Html, Img, Preview, Section } from "@react-email/components";
import { ReactNode } from "react";

import { theme } from "../theme/theme.js";

type Props = {
  children: ReactNode;
  preview: string;
  logoSrc?: string;
  logoAlt?: string;
  logoWidth?: number | string;
  logoHeight?: number | string;
};

const LOGO_SVG = `<svg width="111" height="183" viewBox="0 0 111 183" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_1533_6455)">
<path fill-rule="evenodd" clip-rule="evenodd" d="M51.2939 40.0801C67.744 40.0801 80.4787 43.5816 89.3535 50.5029L73.2725 84.4033C74.5545 76.7108 63.9312 70.1172 51.1104 70.1172C39.7548 70.1172 31.3301 72.6814 31.3301 80.7402C31.3301 83.6689 32.9502 85.625 35.999 87.1455C26.296 87.6743 8.54654 84.5972 2.75977 68.1308C9.16297 50.328 26.4407 40.0801 51.2939 40.0801Z" fill="url(#paint0_linear_1533_6455)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.74805 68.0896C8.53553 84.5556 26.2868 87.6305 35.9893 87.1013C42.6647 90.4304 56.1872 91.6712 74.5439 96.449C85.215 99.2515 95.6941 103.26 102.513 111.423C103.043 129.464 86.9371 147.266 77.1016 147.266L74.6416 147.104C77.244 145.127 78.7568 142.712 78.7568 140.04C78.7567 130.516 67.2178 129.05 43.2246 124.471C22.7111 120.625 0 113.299 0 84.9099C6.41763e-06 78.7415 0.940906 73.1147 2.74805 68.0896Z" fill="url(#paint1_linear_1533_6455)"/>
<path d="M102.516 111.423C107.284 117.13 110.263 124.867 110.263 135.644C110.263 172.092 80.2253 182.715 50.9204 182.715C40.3117 182.715 19.891 180.308 8.39502 163.851L28.2085 133.629C28.2085 146.084 36.8171 152.495 54.3999 152.495C62.8836 152.495 70.2905 150.413 74.645 147.104L77.105 147.266C86.9404 147.266 103.046 129.465 102.516 111.423Z" fill="url(#paint2_linear_1533_6455)"/>
<path d="M51.4681 30.9218C42.5446 30.9218 35.3107 23.9997 35.3107 15.4609C35.3107 6.92208 42.5446 0 51.4681 0C60.3916 0 67.6255 6.92208 67.6255 15.4609C67.6255 23.9997 60.3916 30.9218 51.4681 30.9218Z" fill="#123A4D"/>
</g>
<defs>
<linearGradient id="paint0_linear_1533_6455" x1="86.1493" y1="50.9704" x2="19.7727" y2="76.031" gradientUnits="userSpaceOnUse">
<stop stop-color="#123A4D"/>
<stop offset="1" stop-color="#2563EB"/>
</linearGradient>
<linearGradient id="paint1_linear_1533_6455" x1="19.8174" y1="84.5083" x2="94.5435" y2="135.884" gradientUnits="userSpaceOnUse">
<stop stop-color="#123A4D"/>
<stop offset="1" stop-color="#00BEC8"/>
</linearGradient>
<linearGradient id="paint2_linear_1533_6455" x1="90.3711" y1="121.45" x2="19.3218" y2="147.069" gradientUnits="userSpaceOnUse">
<stop stop-color="#123A4D"/>
<stop offset="1" stop-color="#CEFF2F"/>
</linearGradient>
<clipPath id="clip0_1533_6455">
<rect width="111" height="183" fill="white"/>
</clipPath>
</defs>
</svg>`;

const DEFAULT_LOGO_SRC = `data:image/svg+xml;utf8,${encodeURIComponent(LOGO_SVG)}`;

export default function EmailLayout({
  children,
  preview,
  logoSrc = DEFAULT_LOGO_SRC,
  logoAlt = "Servel",
  logoWidth = 48,
  logoHeight = 48,
}: Props) {
  return (
    <Html>
      <Head />
      <Preview>{preview}</Preview>

      <Body
        style={{
          backgroundColor: theme.colors.background,
          fontFamily: theme.typography.fontFamily,
          margin: 0,
          padding: `${theme.spacing.lg} ${theme.spacing.sm}`,
        }}
      >
        <Container
          style={{
            maxWidth: "560px",
            margin: "0 auto",
            backgroundColor: theme.colors.card,
            borderRadius: theme.radius.card,
            padding: `${theme.spacing.lg} ${theme.spacing.md}`,
            boxShadow: theme.shadows.card,
          }}
        >
          <Section style={{ marginBottom: theme.spacing.lg }}>
            <Img
              src={logoSrc}
              width={logoWidth}
              height={logoHeight}
              alt={logoAlt}
              style={{ display: "block" }}
            />
          </Section>

          {children}
        </Container>
      </Body>
    </Html>
  );
}
