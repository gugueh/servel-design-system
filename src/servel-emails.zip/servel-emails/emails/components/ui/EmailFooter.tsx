import { Link, Section } from "@react-email/components";

import EmailText from "./EmailText.js";
import { theme } from "../theme/theme.js";

type Props = {
  disclaimer?: string;
};

export default function EmailFooter({
  disclaimer = "Si no realizaste esta acción, podés ignorar este mensaje.",
}: Props) {
  return (
    <Section
      style={{
        borderTop: `1px solid ${theme.colors.border}`,
        marginTop: theme.spacing.xl,
        paddingTop: theme.spacing.xl,
      }}
    >
      <EmailText>{disclaimer}</EmailText>

      <EmailText style={{ marginTop: theme.spacing.md }}>
        ¿Necesitás ayuda?{" "}
        <Link
          href="mailto:soporte@servel.com"
          style={{
            color: theme.colors.link,
            textDecoration: "none",
            fontWeight: "600",
          }}
        >
          soporte@servel.com
        </Link>
      </EmailText>

      <EmailText
        style={{
          ...theme.typography.small,
          marginTop: theme.spacing.md,
        }}
      >
        <Link href="https://servel.com" style={{ color: theme.colors.link, textDecoration: "none" }}>
          servel.com
        </Link>{" "}
        ·{" "}
        <Link href="https://servel.com/terminos" style={{ color: theme.colors.link, textDecoration: "none" }}>
          Términos
        </Link>{" "}
        ·{" "}
        <Link href="https://servel.com/privacidad" style={{ color: theme.colors.link, textDecoration: "none" }}>
          Privacidad
        </Link>
      </EmailText>

      <EmailText
        style={{
          fontSize: "12px",
          color: "#9ca3af",
          marginTop: theme.spacing.md,
        }}
      >
        © Servel · Argentina
      </EmailText>
    </Section>
  );
}
