import { Text } from "@react-email/components";
import { CSSProperties } from "react";

import { theme } from "../theme/theme.js";

type Props = {
  children: React.ReactNode;
  style?: CSSProperties;
};

export default function EmailText({ children, style }: Props) {
  return (
    <Text
      style={{
        ...theme.typography.body,
        color: theme.colors.muted,
        margin: 0,
        ...style,
      }}
    >
      {children}
    </Text>
  );
}
