import { Link } from "@react-email/components";
import { CSSProperties } from "react";

import { theme } from "../theme/theme.js";

type Props = {
  href: string;
  children: React.ReactNode;
  style?: CSSProperties;
};

export default function EmailButton({ href, children, style }: Props) {
  return (
    <Link
      href={href}
      style={{
        backgroundColor: theme.colors.primary,
        borderRadius: theme.radius.button,
        color: "#ffffff",
        display: "inline-block",
        fontWeight: "600",
        padding: "12px 18px",
        textDecoration: "none",
        ...style,
      }}
    >
      {children}
    </Link>
  );
}
