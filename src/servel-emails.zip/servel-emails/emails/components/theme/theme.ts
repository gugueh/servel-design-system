export const theme = {
  colors: {
    background: "#F1F5F9",
    card: "#FFFFFF",
    surface: "#F8FAFC",

    text: "#0F172A",
    muted: "#475569",

    border: "#E2E8F0",

    primary: "#0F766E",
    link: "#0EA5E9",

    success: "#10B981",
    danger: "#EF4444",
  },

  radius: {
    card: "24px",
    button: "14px",
    otp: "20px",
  },

  spacing: {
    xs: "8px",
    sm: "16px",
    md: "24px",
    lg: "32px",
    xl: "40px",
  },

  typography: {
    fontFamily:
      "SF Pro Display, SF Pro Text, -apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Arial, sans-serif",

    title: {
      fontSize: "32px",
      lineHeight: "40px",
      fontWeight: "700",
    },

    body: {
      fontSize: "16px",
      lineHeight: "26px",
    },

    small: {
      fontSize: "13px",
      lineHeight: "22px",
    },
  },

  shadows: {
    card: "0 2px 10px rgba(0,0,0,0.04)",
  },
};
