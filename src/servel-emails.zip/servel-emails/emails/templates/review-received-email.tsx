import { Heading, Section } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import EmailButton from "../components/ui/EmailButton.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type Props = {
  ctaUrl: string;
};

export default function ReviewReceivedEmail({ ctaUrl }: Props) {
  return (
    <EmailLayout preview="Recibiste una nueva reseña en Servel">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        Recibiste una nueva reseña
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>Hola 👋</EmailText>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        Un cliente dejó una reseña sobre uno de tus servicios recientes.
      </EmailText>

      <EmailText style={{ marginTop: theme.spacing.md }}>
        Las reseñas ayudan a generar confianza y mejorar tu visibilidad dentro de Servel.
      </EmailText>

      <Section style={{ marginTop: theme.spacing.xl }}>
        <EmailButton href={ctaUrl} style={{ padding: "14px 18px" }}>
          Ver reseña
        </EmailButton>
      </Section>

      <EmailText style={{ marginTop: theme.spacing.xl, color: theme.colors.text }}>
        Gracias por seguir ofreciendo una buena experiencia.
      </EmailText>

      <EmailFooter disclaimer="Si no reconocés esta actividad, podés contactarnos desde la app." />
    </EmailLayout>
  );
}
