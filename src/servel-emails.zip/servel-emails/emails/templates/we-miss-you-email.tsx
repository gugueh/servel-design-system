import { Heading, Section } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import EmailButton from "../components/ui/EmailButton.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type Props = {
  ctaUrl: string;
};

export default function WeMissYouEmail({ ctaUrl }: Props) {
  return (
    <EmailLayout preview="Hace tiempo que no te vemos en Servel">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        Hace tiempo que no te vemos
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>
        Tu perfil y tus servicios siguen disponibles en Servel.
      </EmailText>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        Cuando quieras, podés volver a activar tu agenda y comenzar a recibir nuevas solicitudes.
      </EmailText>

      <Section style={{ marginTop: theme.spacing.xl }}>
        <EmailButton href={ctaUrl} style={{ padding: "14px 18px" }}>
          Volver a Servel
        </EmailButton>
      </Section>

      <Section
        style={{
          borderTop: `1px solid ${theme.colors.border}`,
          marginTop: theme.spacing.xl,
          paddingTop: theme.spacing.xl,
        }}
      >
        <EmailText>
          Muchos especialistas usan Servel todos los días para organizar trabajos, gestionar clientes y hacer crecer su
          actividad.
        </EmailText>
        <EmailText style={{ marginTop: theme.spacing.md }}>
          Tu cuenta sigue lista para continuar cuando vos quieras.
        </EmailText>
      </Section>

      <EmailFooter disclaimer="Si no querés recibir este tipo de recordatorios, podés ignorar este mensaje." />
    </EmailLayout>
  );
}
