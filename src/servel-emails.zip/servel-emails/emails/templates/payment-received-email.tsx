import { Heading, Section, Text } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import EmailButton from "../components/ui/EmailButton.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type DetailRowProps = {
  label: string;
  value: string;
};

function DetailRow({ label, value }: DetailRowProps) {
  return (
    <Section style={{ marginTop: theme.spacing.sm }}>
      <Text
        style={{
          margin: 0,
          ...theme.typography.small,
          color: theme.colors.muted,
        }}
      >
        {label}
      </Text>
      <Text
        style={{
          margin: "4px 0 0 0",
          ...theme.typography.body,
          color: theme.colors.text,
          fontWeight: "600",
        }}
      >
        {value}
      </Text>
    </Section>
  );
}

type Props = {
  amount: string;
  date: string;
  service: string;
  ctaUrl: string;
  operationId?: string;
  payerName?: string;
  paymentMethod?: string;
  status?: string;
};

export default function PaymentReceivedEmail({
  amount,
  date,
  service,
  ctaUrl,
  operationId,
  payerName,
  paymentMethod,
  status = "Acreditado",
}: Props) {
  return (
    <EmailLayout preview="Pago recibido en Servel">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        Pago recibido
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>Hola 👋</EmailText>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        Ya acreditamos el pago correspondiente a uno de tus servicios.
      </EmailText>

      <Section
        style={{
          backgroundColor: theme.colors.surface,
          border: `1px solid ${theme.colors.border}`,
          borderRadius: theme.radius.otp,
          padding: theme.spacing.lg,
          marginTop: theme.spacing.xl,
        }}
      >
        <Heading
          as="h2"
          style={{
            fontSize: "18px",
            lineHeight: "26px",
            fontWeight: "700",
            color: theme.colors.text,
            margin: 0,
          }}
        >
          Detalle del pago
        </Heading>

        <DetailRow label="Monto" value={amount} />
        <DetailRow label="Fecha" value={date} />
        <DetailRow label="Servicio" value={service} />
        <DetailRow label="Estado" value={status} />
        {paymentMethod ? <DetailRow label="Medio de pago" value={paymentMethod} /> : null}
        {payerName ? <DetailRow label="Cliente" value={payerName} /> : null}
        {operationId ? <DetailRow label="ID de operación" value={operationId} /> : null}
      </Section>

      <Section
        style={{
          borderTop: `1px solid ${theme.colors.border}`,
          marginTop: theme.spacing.xl,
          paddingTop: theme.spacing.xl,
        }}
      >
        <EmailText style={{ color: theme.colors.text }}>
          Podés revisar el detalle completo y tus movimientos desde la app.
        </EmailText>

        <Section style={{ marginTop: theme.spacing.lg }}>
          <EmailButton href={ctaUrl} style={{ padding: "14px 18px" }}>
            Ver movimientos
          </EmailButton>
        </Section>

        <EmailText style={{ marginTop: theme.spacing.lg }}>
          Si no reconocés este pago, revisá la actividad en tu cuenta y contactanos desde la app para ayudarte.
        </EmailText>
      </Section>

      <EmailFooter disclaimer="Este es un aviso automático de Servel." />
    </EmailLayout>
  );
}
