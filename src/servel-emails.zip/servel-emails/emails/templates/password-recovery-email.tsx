import { Heading, Section } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import OTPBox from "../components/ui/OTPBox.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type Props = {
  code: string;
};

export default function PasswordRecoveryEmail({ code }: Props) {
  return (
    <EmailLayout preview="Recuperá el acceso a tu cuenta de Servel">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        Recuperá tu cuenta
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>Hola 👋</EmailText>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        Recibimos una solicitud para recuperar el acceso a tu cuenta de Servel.
      </EmailText>

      <Section
        style={{
          marginTop: theme.spacing.xl,
        }}
      >
        <Heading
          as="h2"
          style={{
            fontSize: "18px",
            lineHeight: "26px",
            fontWeight: "700",
            color: theme.colors.text,
            margin: 0,
          }}
        >
          Tu código de verificación
        </Heading>
        <OTPBox code={code} label="" />
      </Section>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>
        Ingresalo en la app para continuar.
      </EmailText>

      <EmailText
        style={{
          marginTop: theme.spacing.sm,
          color: theme.colors.danger,
          fontSize: "14px",
        }}
      >
        ⏳ Este código vencerá en unos minutos por seguridad.
      </EmailText>

      <Section
        style={{
          borderTop: `1px solid ${theme.colors.border}`,
          marginTop: theme.spacing.xl,
          paddingTop: theme.spacing.xl,
        }}
      >
        <EmailText style={{ color: theme.colors.text }}>
          Si no solicitaste este cambio, podés ignorar este mensaje. Tu cuenta seguirá protegida.
        </EmailText>

        <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>¿Necesitás ayuda?</EmailText>
        <EmailText style={{ marginTop: theme.spacing.sm }}>Estamos para ayudarte desde la app de Servel.</EmailText>
      </Section>

      <EmailFooter disclaimer="Si no solicitaste recuperar tu cuenta, podés ignorar este mensaje." />
    </EmailLayout>
  );
}
