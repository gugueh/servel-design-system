import { Heading, Section } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import EmailButton from "../components/ui/EmailButton.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type Props = {
  newDate: string;
  ctaUrl: string;
};

export default function ServiceRescheduledEmail({ newDate, ctaUrl }: Props) {
  return (
    <EmailLayout preview="Servicio reprogramado en Servel">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        Servicio reprogramado
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>Hola 👋</EmailText>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        La fecha de uno de tus servicios fue actualizada correctamente.
      </EmailText>

      <Section
        style={{
          backgroundColor: theme.colors.surface,
          border: `1px solid ${theme.colors.border}`,
          borderRadius: theme.radius.otp,
          padding: theme.spacing.lg,
          marginTop: theme.spacing.xl,
        }}
      >
        <Heading
          as="h2"
          style={{
            fontSize: "18px",
            lineHeight: "26px",
            fontWeight: "700",
            color: theme.colors.text,
            margin: 0,
          }}
        >
          Nueva fecha
        </Heading>

        <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text, fontWeight: "600" }}>
          {newDate}
        </EmailText>
      </Section>

      <EmailText style={{ marginTop: theme.spacing.xl, color: theme.colors.text }}>
        Podés revisar todos los detalles desde la app.
      </EmailText>

      <Section style={{ marginTop: theme.spacing.lg }}>
        <EmailButton href={ctaUrl} style={{ padding: "14px 18px" }}>
          Ver servicio
        </EmailButton>
      </Section>

      <EmailFooter disclaimer="Si no reconocés este cambio, podés contactarnos desde la app." />
    </EmailLayout>
  );
}
