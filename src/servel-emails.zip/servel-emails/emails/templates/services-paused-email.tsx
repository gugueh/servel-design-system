import { Heading, Section } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import EmailButton from "../components/ui/EmailButton.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type Props = {
  ctaUrl: string;
};

export default function ServicesPausedEmail({ ctaUrl }: Props) {
  return (
    <EmailLayout preview="Tus servicios están pausados temporalmente">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        Tus servicios están pausados temporalmente
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>Hola 👋</EmailText>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        Notamos algunas solicitudes pendientes sin respuesta y pausamos temporalmente tus servicios para evitar
        inconvenientes con clientes y proteger tu reputación dentro de Servel.
      </EmailText>

      <Section
        style={{
          borderTop: `1px solid ${theme.colors.border}`,
          marginTop: theme.spacing.xl,
          paddingTop: theme.spacing.xl,
        }}
      >
        <EmailText style={{ color: theme.colors.text }}>Podés activarlos nuevamente cuando quieras desde la app.</EmailText>

        <Section style={{ marginTop: theme.spacing.lg }}>
          <EmailButton href={ctaUrl} style={{ padding: "14px 18px" }}>
            Activar servicios
          </EmailButton>
        </Section>
      </Section>

      <EmailFooter disclaimer="Si necesitás ayuda, podés escribirnos desde la app." />
    </EmailLayout>
  );
}
