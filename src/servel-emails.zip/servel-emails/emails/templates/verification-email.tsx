import { Heading } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import OTPBox from "../components/ui/OTPBox.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type Props = {
  code: string;
};

export default function VerificationEmail({ code }: Props) {
  return (
    <EmailLayout preview="Tu código de verificación de Servel">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        👋 Ya falta poco para empezar en Servel.
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        Queremos asegurarnos de que tu cuenta sea segura y realmente tuya.
      </EmailText>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>
        Tu código de verificación es:
      </EmailText>

      <OTPBox code={code} label="" />

      <EmailText
        style={{
          marginTop: theme.spacing.sm,
          color: theme.colors.danger,
          fontSize: "14px",
        }}
      >
        ⏳ Este código vencerá en unos minutos.
      </EmailText>

      <EmailFooter disclaimer="Si no intentaste crear una cuenta, podés ignorar este mensaje." />
    </EmailLayout>
  );
}
