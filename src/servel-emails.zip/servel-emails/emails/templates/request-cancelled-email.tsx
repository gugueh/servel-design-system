import { Heading, Section } from "@react-email/components";

import EmailLayout from "../components/ui/EmailLayout.js";
import EmailText from "../components/ui/EmailText.js";
import EmailButton from "../components/ui/EmailButton.js";
import EmailFooter from "../components/ui/EmailFooter.js";

import { theme } from "../components/theme/theme.js";

type Props = {
  ctaUrl: string;
};

export default function RequestCancelledEmail({ ctaUrl }: Props) {
  return (
    <EmailLayout preview="La solicitud fue cancelada automáticamente">
      <Heading
        style={{
          ...theme.typography.title,
          color: theme.colors.text,
          margin: 0,
        }}
      >
        La solicitud fue cancelada automáticamente
      </Heading>

      <EmailText style={{ marginTop: theme.spacing.lg, color: theme.colors.text }}>Hola 👋</EmailText>

      <EmailText style={{ marginTop: theme.spacing.md, color: theme.colors.text }}>
        Como no recibimos una respuesta a tiempo, la solicitud fue cancelada automáticamente y se realizó el reembolso
        correspondiente al cliente.
      </EmailText>

      <Section
        style={{
          borderTop: `1px solid ${theme.colors.border}`,
          marginTop: theme.spacing.xl,
          paddingTop: theme.spacing.xl,
        }}
      >
        <EmailText style={{ color: theme.colors.text }}>
          Para evitar inconvenientes y proteger tu reputación dentro de Servel, te recomendamos revisar tus servicios y
          disponibilidad.
        </EmailText>

        <Section style={{ marginTop: theme.spacing.lg }}>
          <EmailButton href={ctaUrl} style={{ padding: "14px 18px" }}>
            Revisar agenda
          </EmailButton>
        </Section>
      </Section>

      <EmailFooter disclaimer="Si creés que esto es un error, podés contactarnos desde la app." />
    </EmailLayout>
  );
}
