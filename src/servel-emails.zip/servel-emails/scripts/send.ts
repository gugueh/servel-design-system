import "dotenv/config";
import nodemailer from "nodemailer";
import { render } from "@react-email/render";
import { RateLimiterMemory } from "rate-limiter-flexible";

import VerificationEmail from "../emails/templates/verification-email.js";

async function main() {
  const otpLimiter = new RateLimiterMemory({
    points: process.env.OTP_LIMIT_POINTS ? Number(process.env.OTP_LIMIT_POINTS) : 5,
    duration: process.env.OTP_LIMIT_DURATION ? Number(process.env.OTP_LIMIT_DURATION) : 60,
  });

  const ip = process.env.OTP_LIMIT_KEY ?? "local";

  try {
    await otpLimiter.consume(ip);
  } catch {
    console.error("Rate limit alcanzado. Probá de nuevo en unos segundos.");
    process.exit(1);
  }

  const smtpHost = process.env.SMTP_HOST ?? "smtp.gmail.com";
  const smtpPort = process.env.SMTP_PORT ? Number(process.env.SMTP_PORT) : 587;
  const smtpSecure = process.env.SMTP_SECURE ? process.env.SMTP_SECURE === "true" : false;
  const smtpUser = process.env.SMTP_USER ?? "TU_MAIL";
  const smtpPass = process.env.SMTP_PASS ?? "TU_APP_PASSWORD";
  const mailTo = process.env.MAIL_TO ?? "test@gmail.com";
  const mailFrom = process.env.MAIL_FROM ?? '"Servel" <noreply@servel.com>';

  const transporter = nodemailer.createTransport({
    host: smtpHost,
    port: smtpPort,
    secure: smtpSecure,

    auth: {
      user: smtpUser,
      pass: smtpPass,
    },
  });

  const html = await render(
    VerificationEmail({
      code: "482 913",
    }),
  );

  await transporter.sendMail({
    from: mailFrom,
    to: mailTo,
    subject: "Verificá tu cuenta",
    html,
  });

  console.log("Mail enviado");
}

main();
