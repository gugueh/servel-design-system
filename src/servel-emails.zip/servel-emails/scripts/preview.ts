import "dotenv/config";
import { render } from "@react-email/render";
import fs from "node:fs";

import VerificationEmail from "../emails/templates/verification-email.js";

async function main() {
  const html = await render(
    VerificationEmail({
      code: "482 913",
    }),
  );

  fs.writeFileSync("preview.html", html);

  console.log("Preview generada");
}

main();
